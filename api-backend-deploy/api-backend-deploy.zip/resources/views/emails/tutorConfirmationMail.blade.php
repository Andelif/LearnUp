<!DOCTYPE html>
<html>
<head>
    <title>Tuition Confirmation</title>
</head>
<body>
    <h2>Hello,</h2>
    <p>Your tuition has been confirmed, and payment has been completed.</p>
    <p>Tuition ID: {{ $application->ApplicationID }}</p>
    <p>Amount Paid: Completed</p>
    <p>Thank you for being part of our platform!</p>
</body>
</html>
